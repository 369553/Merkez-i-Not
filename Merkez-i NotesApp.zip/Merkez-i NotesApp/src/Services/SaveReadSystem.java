
package Services;

import Base.Category;
import Base.Note;
import Base.SystemSettings;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

public class SaveReadSystem {
    private static SaveReadSystem SWSystem;
    //private static File managementFile, notesFile;
    
    public SaveReadSystem(){
        
        
    }
    
    public boolean saveNote(Note note){
        File currentFile;
        /*Note'u olduğu gibi kaydet; sonuna category ismi, tarihi vs. yaz*/
        //Burada kaydetme işlemleri, dosya tipi işaretlemeleri, kayıt konumu, diske yazma izni olup olmadığı kontrol edilmeli, yapılmalı
        return true;
    }
    
    public static SaveReadSystem usesaveReadSystem(){
        if (SWSystem == null){
            SWSystem = new SaveReadSystem();
        }
        return SWSystem;
    }
    
    public StringBuilder readMainFromFile() throws FileNotFoundException{
        String path = SystemSettings.getSettings().getPATHPosition();
        File managementFile = new File(path + "/centersys.mn");
        StringBuilder centersysContent = new StringBuilder();
        if(!managementFile.exists())
            throw new RuntimeException("Temel sistem dosyası bulunamadı");
        BufferedReader bufRead = null;
        try{
            bufRead = new BufferedReader(new FileReader(managementFile));
            String takedLine;
            while((takedLine=bufRead.readLine())!=null){
                centersysContent.append(takedLine);
            }
        }
        catch(Exception e_read){
            e_read.printStackTrace();
        }
        finally{
            if (bufRead!=null){
                try{
                bufRead.close();
                }
                catch(IOException e_io){
                    e_io.printStackTrace();
                }
            }
        }
        
        return centersysContent;
    }
    
    public boolean saveMainToFile(String text){
        String path = SystemSettings.getSettings().getPATHPosition();
        File managementFile = new File(path + "/centersys.mn");
        try {
            managementFile.createNewFile() ;
        }
        catch( IOException e_io ){
            e_io.printStackTrace() ;
            System.err.println( "Temel sistem kayıt dosyası oluşturulamadı!" ) ;
        }
        try{
            BufferedWriter writer = new BufferedWriter( new FileWriter( managementFile.getAbsoluteFile() ) ) ;
            long space = managementFile.getTotalSpace() ;
            writer.write(text);
            writer.flush() ;
            writer.close();
            if ( managementFile.getTotalSpace() < space )
                return true ;
            else 
                return false ;
        }
        catch(IOException e_IO){
            e_IO.printStackTrace();
            System.err.println("Veriler dosyaya yazılamadı");
        }
        return true;
    }
    
    /*public boolean writeCategory(Category category, boolean is_new) throws FileNotFoundException, UnsupportedEncodingException{
        String path = SystemSettings.getSettings().getPATHPosition();
        FileInputStream fis = null;
        InputStreamReader inputStream;
        inputStream = new InputStreamReader(fis, "UTF-8");
        FileReader fileRead = new FileReader(path + "/centersys.mn");
        BufferedReader bufRead = new BufferedReader(inputStream);
        bufRead.
        
        return true;
    }*/
    
}
