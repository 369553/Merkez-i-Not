package Services;
//Bu tür servisler interface ya da abstract class mı olmalı, düşün
public class BackupingService {
    
    public BackupingService () {
        
    }
    
    
}
