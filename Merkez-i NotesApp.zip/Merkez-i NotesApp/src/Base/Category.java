package Base;
//Kategori oluşturma aşamasında tasarım desenlerinden builder ı kullan.
import View.ClasorIcon;
import View.Theme;
import java.util.Date;
//Date sınıfı kullanımını öğren, klasör son değiştirme tarihi içerisindeki en son notun değiştirilme tarihi oalrak yapılabilir, düşün

public class Category {
    Note notes[];
    String name;
    String explanation;
    int number_of_notes;
    //Theme theme;
    ClasorIcon icon;
    Date last_change_time;
    Date produce_time;
    
    public Category (String name, ClasorIcon icon) {
        this.name = name;
        this.icon = icon;
    }
    
    public Category (String name) {
        this.name = name;
        this.icon = new ClasorIcon(0);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public int getNumber_of_notes() {
        return number_of_notes;
    }

    public void setNumber_of_notes(int number_of_notes) {
        this.number_of_notes = number_of_notes;
    }

    /*public Theme getTheme() {
        return theme;
    }

    public void setTheme(Theme theme) {
        this.theme = theme;
    }*/

    public ClasorIcon getIcon() {
        return icon;
    }

    public void setIcon(ClasorIcon icon) {
        this.icon = icon;
    }

    public Date getLast_change_time() {
        return last_change_time;
    }

    public void setLast_change_time(Date last_change_time) {
        this.last_change_time = last_change_time;
    }

    public Date getProduce_time() {
        return produce_time;
    }

    public void setProduce_time(Date produce_time) {
        this.produce_time = produce_time;
    }
    
    
}
