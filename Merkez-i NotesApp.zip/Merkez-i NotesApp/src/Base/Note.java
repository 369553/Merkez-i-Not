package Base;

import java.util.Date;
//Sonraki aşamalarda tag (etiket) eklenebilir, yapılacak not, metin notu gibi tasnifler de yapılabilir.
public class Note {
    String name;
    String malumat;
    Date last_change_time;
    Date produce_time;
    Category inCategory;
    
    public Note (String name, String malumat) {
        this.name = name;
        this.malumat = malumat;
    }
    
    public Note (String name) {
        this.name = name;
        this.malumat = "";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMalumat() {
        if (malumat == null){
            malumat = new String("");
        }
        return malumat;
    }

    public void setMalumat(String malumat) {
        this.malumat = malumat;
    }

    public Date getLast_change_time() {
        if (last_change_time == null){
            last_change_time = produce_time;
        }
        return last_change_time;
    }

    public void setLast_change_time(Date last_change_time) {
        this.last_change_time = last_change_time;
    }

    public Date getProduce_time() {
        if (produce_time == null){
            produce_time = new Date(2021, 3, 2, 3, 55);//Tarih sistem tarihi olarak otomatik alınmalı.
        }
        return produce_time;
    }

    public void setProduce_time(Date produce_time) {
        this.produce_time = produce_time;
    }

    public Category getInCategory() {
        if (inCategory == null){
            System.err.println("Bu not herhangi bir kategoride değil");//Kategori kelimesinin Türkçe'sini bul
            return null;//Dönüş tipi başka bir şey olabilir: eğer ana ekrandakileri kategorisiz kategorisi olarak tanımlammışsak
        }
        return inCategory;
    }

    public void setInCategory(Category inCategory) {
        this.inCategory = inCategory;
    }
    
    
    
    
}
