package Base;
//not istatistikleri, çizim, etiketleme, zaman çizelgesi sonra ekle
//Dil seçeneği eklenmeli
import View.MainView;

/**
 *
 * @author SOLAKOĞULLARI, MEHMET AKİF SOLAK
 */
public class MerkezINotesApp {
    
    public static void main(String[] args) {
        MainView view = new MainView();
    }
    
}
