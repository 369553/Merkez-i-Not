package Base;
//KOD YAZIM STANDARTLARINI BELİRLE, kullanıcı özelliği ekle

import View.Theme;

public class SystemSettings {
    static String language, themeName, PATHPosition ;
    private static SystemSettings settings;
    static Theme currentTheme ;
    static boolean isUser_entry;
    static StringBuilder centersys;
    static boolean is_logging;
    static boolean is_autoSaving;
    //static User currentUser;
    
    private SystemSettings ( String language, String themeName, String PATH ) {
        this.themeName = themeName ;
        this.language = language ;
        this.PATHPosition = PATH;
        
        isUser_entry = false;
    }
    
    public static SystemSettings getSettings() {
        if (settings == null ) {
            settings = new SystemSettings("TÜRKÇE", "Dark", "C:\\Users\\SOLAKOĞULLARI\\Documents") ;
        }
        return settings;
    }
    
    public static Theme getCurrentTheme(){
        if ( currentTheme == null ) {
            currentTheme = new Theme( SystemSettings.getSettings().getThemeName() ) ;
        }
        return currentTheme;
    }
    public static void setCurrentTheme(Theme CurrentTheme) {
        SystemSettings.currentTheme = CurrentTheme;
    }
    public static String getLanguage() {
        if ( settings == null ) {
            getSettings();
        }
        return language;
    }

    public static void setLanguage(String language) {
        SystemSettings.language = language;
    }

    public static String getThemeName() {
        if ( settings == null ) {
            getSettings();
        }
        return themeName;
    }

    public static void setThemeName(String themeName) {
        SystemSettings.themeName = themeName;
    }

    public static String getPATHPosition() {
        if ( settings == null ) {
            getSettings();
        }
        return PATHPosition;
    }

    public static void setPATHPosition(String PATHPosition) {
        SystemSettings.PATHPosition = PATHPosition;
    }

    public static boolean isUser_Entry() {
        return isUser_entry;
    }

    public void setIs_User_Entry(boolean isUser_entry) {
        this.isUser_entry = isUser_entry;
    }

    public static boolean getIs_logging() {
        if ( settings == null ) {
            getSettings();
        }
        return is_logging;
    }

    public void setIs_logging(boolean is_logging) {
        this.is_logging = is_logging;
    }
    
    public static boolean getIs_autoSaving() {
        if ( settings == null ) {
            getSettings();
        }
        return is_autoSaving;
    }

    public void setIs_autoSaving(boolean is_autoSaving) {
        this.is_autoSaving = is_autoSaving;
    }
    /*public static User getCurrentUser() {
        if ( settings == null ) {
            getSettings();
        }
        if (isUser_entry == false){
            return null;
        }
        return currentUser;
    }

    public static void setCurrentUser(User currentUser) {
        SystemSettings.currentUser = currentUser;
    }*/
    
    @Override //DEĞİŞTİRİLECEK
    public String toString () {
        StringBuilder backValue = new StringBuilder() ;
        backValue.append( "Dil: " + getSettings().getLanguage() + "\nTema: " + getSettings().getThemeName());
        backValue.append( "\nKayıt tut: " ) ;
        if (getSettings().getIs_logging() == true )
            backValue.append ( "Evet" ) ;
        else
            backValue.append ( "Hayır" ) ;
        backValue.append( "\nOtomatik kaydet: " ) ;
        if (getSettings().getIs_autoSaving()== true )
            backValue.append ( "Evet" ) ;
        else
            backValue.append ( "Hayır" ) ;
        backValue.append( "\nDosya yolu: " + getSettings().getPATHPosition() ) ;
        return backValue.toString() ;
    }
    
}
