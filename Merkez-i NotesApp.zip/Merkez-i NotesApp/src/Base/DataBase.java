package Base;
//Temalar ve diğer bilgiler nasıl tutulmalı, düşün, araştır gerekirse...

import java.util.Date;

public class DataBase {
    private static DataBase Database;
    public Category[] categories;
    Note[] notes;
//    Theme[] themes;
    
    private DataBase(){
        
    }
    
    public static DataBase getDatabase () {
        if ( Database == null ) {
            Database = new DataBase () ;
        }
        return Database ;
    }
    
    public Category[] getCategories(){
        /*if (categories == null){
            categories = new Category [FromCategoriesTable.number];
            for (int i = 0; i < FromCategoriesTable.number; i++){
                categories[i] = new Category("....");
            }
        }*/
        return categories;
    }
    
    public Note[] getNotes(){
        /*if (categories == null){
            notes = new Note [FromNotesTable.number];
            for (int i = 0; i < FromNotesTable.number; i++){
                notes[i] = new Note("....");
            }
        }*/
        return notes;
    }
    
    public String[] getNotesNames(){
        String[] noteNames;
        noteNames = new String[getDatabase().getNotes().length];
        for (int i = 0; i < noteNames.length; i++){//i:getNotes() buna benzer bir kullanım şekli vardı, onu öğren
            noteNames[i] = getDatabase().getNotes()[i].getName();
        }
        return noteNames;
    }
    
    public Date[] getNotesChangingDates(){
        Date[] noteDates;
        noteDates = new Date[getNotes().length];
        for (int i = 0; i < noteDates.length; i++){//i:getNotes() buna benzer bir kullanım şekli vardı, onu öğren
            noteDates[i] = getDatabase().getNotes()[i].getLast_change_time();
        }
        return noteDates;
    }
    
    public Date[] getNotesProduceDates(){
        Date[] noteDates;
        noteDates = new Date[getDatabase().getNotes().length];
        for (int i = 0; i < noteDates.length; i++){//i:getNotes() buna benzer bir kullanım şekli vardı, onu öğren
            noteDates[i] = getDatabase().getNotes()[i].getProduce_time();
        }
        return noteDates;
    }
    
    public String[] getCategoryNames(){
        String[] CategoriesNames;
        CategoriesNames = new String[getDatabase().getCategories().length];
        for (int i = 0; i < CategoriesNames.length; i++){//i:getNotes() buna benzer bir kullanım şekli vardı, onu öğren
            CategoriesNames[i] = getDatabase().getCategories()[i].name;
        }
        return CategoriesNames;
    }
}
