package Base;

import javax.swing.ImageIcon;

public class User {
    String name;
    ImageIcon icon;
    private String password;
    private SystemSettings personalSettings;
    
    public User (String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
//FILL:
    public ImageIcon getIcon() {
        if (icon == null){
            icon = new ImageIcon();
        }
        return icon;
    }

    public void setIcon(ImageIcon icon) {
        this.icon = icon;
    }

    public String getPassword() {
        if (password == null){
            return "";
        }
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
//FIX:
    public SystemSettings getPersonalSettings() {
        if ( personalSettings == null){
            personalSettings = SystemSettings.getSettings();
        }
        return personalSettings;
    }

    public void setSettings(SystemSettings settings) {
        this.personalSettings = settings;
    }
    
    
}
