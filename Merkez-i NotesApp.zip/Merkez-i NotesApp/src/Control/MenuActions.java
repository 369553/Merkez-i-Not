package Control;

import View.Add;
import View.MainFrame;
import View.MainPanel;
import View.Menu;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuActions implements ActionListener{
    Menu menu;
    MainPanel MP;
    
    public MenuActions(Menu menu){
        this.menu = menu;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(menu != null){
//                System.out.println("bileşen sayısı: " + MainFrame.getFrame_Main().getContentPane().getComponentCount());
            if (e.getSource() == Menu.getMenu().getB1_ShowCategory()){
                    this.MP = (MainPanel) MainFrame.getFrame_Main().getContentPane().getComponent(0);
                    this.MP.remove(this.MP.getComponent(4));
/*BİLGİ KONTROL*///                    System.err.println("Menu'de kategori göster'e tıklandı");
                /*hangi ekran açıksa onu kaldır*/// this.MP.remove(this.MP.getOptionsPanel());
                MainFrame.getFrame_Main().setVisible(true);
                Add.setAnchor(GridBagConstraints.CENTER);
                Add.setInsets(7, 7, 7, 7);
                Add.ADDCOMP(this.MP, this.MP.getManagPanel(), 0, 1, 4, 1, Add.getInsets(), GridBagConstraints.BOTH, 1.0, 1.0);
                MainFrame.getFrame_Main().repaint();
                MainFrame.getFrame_Main().setVisible(true);
            }
            else if (e.getSource() == Menu.getMenu().getB2_showNotesList()){
                
            }
            else if (e.getSource() == Menu.getMenu().getB3_settings()){
                    this.MP = (MainPanel) MainFrame.getFrame_Main().getContentPane().getComponent(0);
                    this.MP.remove(this.MP.getComponent(4));
/*BİLGİ KONTROL*///                    System.err.println("Menu'de Ayarlar'a tıklandı");
                /*hangi ekran açıksa onu kaldır*/ //this.MP.remove(this.MP.getManagPanel());
                Add.setAnchor(GridBagConstraints.CENTER);
                Add.ADDCOMP(this.MP, this.MP.getOptionsPanel(), 0, 1, 4, 1, Add.getInsets(), GridBagConstraints.BOTH, 1.0, 1.0);
                MainFrame.getFrame_Main().repaint();
                MainFrame.getFrame_Main().setVisible(true);
                
            }
            if (e.getSource() == menu.getB4_backuping()){
                
            }
        }
    }
    
    
    
}
