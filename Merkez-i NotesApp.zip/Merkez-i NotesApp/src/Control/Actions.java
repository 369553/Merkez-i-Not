package Control;

import View.Add;
import View.ListPanel;
import View.MainFrame;
import View.MainPanel;
import View.ManagementPanel;
import View.Menu;
import View.OptionsPanel;
import View.OrganizerMenu;
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

public class Actions implements ActionListener{
    MainPanel MP;
    Menu menu;
    ManagementPanel manPan;
    ListPanel listPanel;
    OrganizerMenu orgMenu;
    
    public Actions(MainPanel panel){
        this.MP = panel;
    }
    
    public Actions (ManagementPanel manPan){
        this.manPan = manPan;
    }
    
    public Actions (ListPanel listPanel){
        this.listPanel = listPanel;
    }
    
    public Actions (OrganizerMenu orgMenu){
        this.orgMenu = orgMenu;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (MP != null){
            if (e.getSource() == MP.getB1_open_menu()){
/*BİLGİ KONTROL*///            System.out.println("görsel bileşen sayısı:" + MainFrame.getFrame_Main().getContentPane().getComponentCount());
                if (MainFrame.getFrame_Main().getContentPane().getComponentCount() == 2){
                    menu = /*(Menu) MainFrame.getFrame_Main().getContentPane().getComponent( 1 );*/Menu.getMenu();
                    MainFrame.getFrame_Main().remove(menu);
                }
                else{
                    menu = Menu.getMenu();
                    MainFrame.getFrame_Main().add(menu, BorderLayout.WEST);
                }
                MainFrame.getFrame_Main().setVisible(true);
            }
            else if(e.getSource() == MP.getB2_open_options()){
                
            }
        }
        
        if (manPan != null){
/*BİLGİ KONTROL*/            if (e.getSource() == manPan.getB1deneme()){
                //System.err.println("çalıştı");
                //System.out.println("büyüklük: " + manPan.getSize());
                this.MP = (MainPanel) MainFrame.getFrame_Main().getContentPane().getComponent(0);
/*BİLGİ KONTROL*///                System.out.println("This.MP'nin component sayısı :" + this.MP.getComponentCount());
                this.MP.remove(this.MP.getComponent(4));
/*BİLGİ KONTROL*///                System.err.println("ManagPanel'de not göster'e tıklandı");
                Add.setAnchor(GridBagConstraints.CENTER);
                Add.ADDCOMP(this.MP, this.MP.getEditPanel(), 0, 1, 4, 1, Add.getInsets(), GridBagConstraints.BOTH, 1.0, 1.0);
                this.MP.getEditPanel().getEditTools().addingListeners();
                this.MP.getEditPanel().addListeners();
                this.MP.getEditPanel().updateTheme();
                MainFrame.getFrame_Main().repaint();
                MainFrame.getFrame_Main().setVisible(true);
            }
        }
        
    /*SONRAYA BIRAK, ListPanel yapıldıktan sonraya...    else if (listPanel != null){
            //if (e.getSource().getClass().getName() == "JButton"){
                System.err.println("sınıf ismi: " + e.getSource().getClass().getName());
            //}
        }*/
    }
    
}
