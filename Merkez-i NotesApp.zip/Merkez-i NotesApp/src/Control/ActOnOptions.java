
package Control;

import Base.SystemSettings;
import View.Add;
import View.MainFrame;
import View.MainPanel;
import View.Menu;
import View.OptionsPanel;
import View.Theme;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActOnOptions implements ActionListener{
    OptionsPanel optionsPanel;
    MainPanel MP;
    String path ;
    
    public ActOnOptions(OptionsPanel optionsPanel){
        this.optionsPanel = optionsPanel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (optionsPanel != null){
            if (e.getSource() == optionsPanel.getB1_chooseLocation()){
                optionsPanel.openChooser();
            }
            else if (e.getSource() == optionsPanel.getChooser() ) {
                getPath();
            }
            
            else if (e.getSource() == optionsPanel.getB2_save()){
                setSettings(optionsPanel);
                this.MP = (MainPanel) MainFrame.getFrame_Main().getContentPane().getComponent(0);
                this.MP.remove(this.MP.getComponent(2));
                MainFrame.getFrame_Main().setVisible(true);
                Add.setAnchor(GridBagConstraints.CENTER);
                Add.setInsets(7, 7, 7, 7);
                Add.ADDCOMP(this.MP, this.MP.getManagPanel(), 0, 1, 2, 1, Add.getInsets(), GridBagConstraints.BOTH, 1.0, 1.0);
                this.MP.updateTheme();
                this.MP.getManagPanel().updateTheme();
                Menu.getMenu().updateTheme();
                this.MP.getOptionsPanel().updateTheme();
                // diğer egörsel bileşenlerin temalarını da güncelle
                MainFrame.getFrame_Main().repaint();
                MainFrame.getFrame_Main().setVisible(true);
            }
        }
    }
    
    public void getPath () {
        if ( optionsPanel.getChooser().getSelectedFile() != null ) {
            path = optionsPanel.getChooser().getSelectedFile().getAbsolutePath() ;
            optionsPanel.getChooser().setSelectedFile( null ) ;
            System.out.println("path: "  + path ) ;
        }
    }
    
    private boolean setSettings( OptionsPanel panel ) {
        String theme = exportTheme ( panel.getComB2_theme().getSelectedIndex() ) ;
        SystemSettings.getSettings().setIs_logging(panel.getCheckB1_isLogging().isSelected());
        SystemSettings.getSettings().setIs_autoSaving(panel.getCheckB2_isAutosave().isSelected());
        SystemSettings.getSettings().setPATHPosition ( this.path ) ;
        SystemSettings.getSettings().setLanguage( panel.getComB1_language().getSelectedItem().toString() ) ;
        SystemSettings.getSettings().setThemeName ( theme ) ;
        SystemSettings.getSettings().setCurrentTheme( new Theme ( theme ) ) ;
        System.out.println( SystemSettings.getSettings().toString() ) ;
        return true ;
    }
    
    public static String exportTheme ( int index ) {
        switch( index ){
            case 0: return "Standard" ;
            case 1: return "Alternative" ;
            case 2: return "Blue" ;
            case 3: return "Purple" ;
            case 4: return "Red" ;
            case 5: return "Gold" ;
            case 6: return "Special" ;
            case 7: return "Dark" ;
            default: return "Standard" ;
        }
    }
    
    
}
