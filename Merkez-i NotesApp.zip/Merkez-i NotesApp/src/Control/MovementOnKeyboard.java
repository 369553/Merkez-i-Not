
package Control;

import View.EditingPanel;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class MovementOnKeyboard implements KeyListener{
    EditingPanel editPanel;
    public MovementOnKeyboard(EditingPanel panel){
        this.editPanel = panel;
    }

    @Override
    public void keyTyped(KeyEvent e) {
        if(editPanel != null){
            if(e.getSource() == editPanel.getTextArea_writingArea()){
            System.err.println("basılan tuş: " + e.getKeyChar());
            }
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
    //TUŞ
    }

    @Override
    public void keyReleased(KeyEvent e) {
    //TUŞ BIRAKILDIĞINDA
    }
    
    
}
