package Control;

import View.EditingPanel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.logging.Level;
import java.util.logging.Logger;

public class WriteAction implements ActionListener{
    EditingPanel editPanel;
    
    public WriteAction(EditingPanel panel){
        this.editPanel = panel;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(editPanel != null){
            if (e.getSource() == editPanel.getEditTools().getB1_inParagraph()){
                System.err.println("imleç konumu : " + editPanel.getTextArea_writingArea().getCaretPosition());
                if (detectParagraph(editPanel.getTextArea_writingArea().getCaretPosition(), false) == true)
                    editPanel.getTextArea_writingArea().setText(applyTab(editPanel.getTextArea_writingArea().getCaretPosition(), true));
            }
            if (e.getSource() == editPanel.getEditTools().getB2_outParagraph()){
                if (detectParagraph(editPanel.getTextArea_writingArea().getCaretPosition(), true) == true){
                    editPanel.getTextArea_writingArea().setText(applyTab(editPanel.getTextArea_writingArea().getCaretPosition(), false));
                }
            }
            /*if (e.getSource() == editPanel.getEditTools().getB3_bold()){//Özellikler dosyanın sonuna eklenmeli ya da ayrı bir dosyada saklanmalı; String biçiminde depolanmalı, bu sayee daha az alan kaplar. Bunun için özel bir format ve o formatı okuyabilen bir küçük okuyucu motora ihtiyaç var
                
            }
            if (e.getSource() == editPanel.getEditTools().getB4_underline()){
                
            }*/
        }
    }
    
    protected boolean detectParagraph(int index, boolean isRequestIsContainTab){
        char lastCharacter;
        boolean isContainTab = false;
        String textOn = editPanel.getTextArea_writingArea().getText();
//        lastCharacter = textOn.charAt(index -1);
        for(int i = index - 1; ;i--){
            lastCharacter = textOn.charAt(i);
            if(lastCharacter == '\n'){
                if (isRequestIsContainTab == false)
                    return true;
                else{
                    if(isContainTab == true)
                        return true;
                    else
                        return false;
                }
            }
            else if(lastCharacter == '\t'){
                if(isRequestIsContainTab == false)
                    continue;
                else
                    isContainTab = true;
            }
            else
                return false;
        }
    }
    
    
    /*public void applyAttributes(){
        
        
        
    }*/
    
    public String applyTab(int caretPosition, boolean is_addTab){
        StringBuilder textToChange;
        textToChange = new StringBuilder(editPanel.getTextArea_writingArea().getText());
        if (is_addTab == true){
            textToChange.insert((caretPosition), '\t');
        }
        else
            textToChange.deleteCharAt((caretPosition - 1));
        return new String(textToChange);
    }
    
}
