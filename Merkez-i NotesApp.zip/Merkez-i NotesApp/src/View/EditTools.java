package View;

import Base.SystemSettings;
import Control.WriteAction;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.BorderFactory;
//import javax.swing.BoxLayout; SİLİNECEK
//import static javax.swing.BoxLayout.X_AXIS; SİLİNECEK
import javax.swing.JButton;
import javax.swing.JPanel;

public class EditTools extends JPanel{
    FlowLayout layout;
    JButton B1_inParagraph, B2_outParagraph, B3_bold, B4_underline;
    WriteAction wrAction;
    private static EditTools editTools;
    
    public EditTools(){
        setLayout(getPanLayout());
        this.add(getB1_inParagraph());
        this.add(getB2_outParagraph());
    //    this.add(getB3_bold());
    //    this.add(getB4_underline());
        this.setPreferredSize(new Dimension(250, 40));
   //     this.setPreferredSize(new Dimension(MainFrame.getFrame_Main().getContentPane().getComponent(0).getHeight(), MainFrame.getFrame_Main().getContentPane().getComponent(0).getWidth()));
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme());
        MainFrame.getFrame_Main().setVisible(true);
        
    }

    public JButton getB1_inParagraph() {
        if (B1_inParagraph == null){
            B1_inParagraph = new JButton(">>");
            Theme.AppTheme(B1_inParagraph, SystemSettings.getSettings().getCurrentTheme());
        }
        return B1_inParagraph;
    }

    public void setB1_inParagraph(JButton B1_inParagraph) {
        this.B1_inParagraph = B1_inParagraph;
    }

    public JButton getB2_outParagraph() {
        if (B2_outParagraph == null){
            B2_outParagraph = new JButton("<<");
            Theme.AppTheme(B2_outParagraph, SystemSettings.getSettings().getCurrentTheme());
        }
        return B2_outParagraph;
    }

    public void setB2_outParagraph(JButton B2_outParagraph) {
        this.B2_outParagraph = B2_outParagraph;
    }

    /*public JButton getB3_bold() {
        if (B3_bold == null){
            B3_bold = new JButton("B");
            Theme.AppTheme(B3_bold, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return B3_bold;
    }

    public void setB3_bold(JButton B3_bold) {
        this.B3_bold = B3_bold;
    }

    public JButton getB4_underline() {
        if (B4_underline == null){
            B4_underline = new JButton("_");
            Theme.AppTheme(B4_underline, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return B4_underline;
    }

    public void setB4_underline(JButton B4_underline) {
        this.B4_underline = B4_underline;
    }*/

    public FlowLayout getPanLayout() {
        if (layout == null){
            layout = new FlowLayout(FlowLayout.LEFT, 3, 3);
        }
        return layout;
    }

    public void setPanLayout(FlowLayout layout) {
        this.layout = layout;
    }

    public WriteAction getWrAction() {
        if (wrAction == null){
            wrAction = new WriteAction(EditingPanel.getEditPanel());
        }
        return wrAction;
    }

    public void setWrAction(WriteAction wrAction) {
        this.wrAction = wrAction;
    }

    public static EditTools getEditTools() {
        if (editTools == null){
            editTools = new EditTools();
        }
        return editTools;
    }

    public static void setEditTools(EditTools editTools) {
        EditTools.editTools = editTools;
    }
    
    public void addingListeners(){
        EditTools.getEditTools().getB1_inParagraph().addActionListener(getWrAction());
        EditTools.getEditTools().getB2_outParagraph().addActionListener(getWrAction());
    /*    EditTools.getEditTools().getB3_bold().addActionListener(getWrAction());
        EditTools.getEditTools().getB4_underline().addActionListener(getWrAction());*/
    }
    
    public void updateTheme(){
        Theme.AppTheme(B2_outParagraph, SystemSettings.getSettings().getCurrentTheme());
        Theme.AppTheme(B1_inParagraph, SystemSettings.getSettings().getCurrentTheme());
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme());
    }
    
}
