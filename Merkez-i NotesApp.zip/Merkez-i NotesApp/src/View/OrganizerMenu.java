
package View;

import Base.SystemSettings;
import Control.Actions;
import static View.Menu.getL_Main;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class OrganizerMenu extends JPanel{
    private static OrganizerMenu orgMenu;
    NoteButton[] noteButtons;
    ClasorButton[] categoriesButtons;
    JLabel[] numberNotes;
    GridBagLayout Layout_main;
    Actions actOnOrganizer;
    
    public OrganizerMenu(){
        this.setLayout( getLayout_main()) ;
        addButtons();
        
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme());
    }
    
    /*public void updateTheme(){//Fonksiyonların statik olup olmaması gerektiği, statik olmayan fonksiyondan statik bir şeye erişilmesinin ne demek olduğu ve bunun risk içerip içermediği hakkında araştırma yap
        Theme.AppTheme(L1_name, SystemSettings.getSettings().getCurrentTheme() ) ;
        Theme.AppTheme(b4_backuping, SystemSettings.getSettings().getCurrentTheme() ) ;
        Theme.AppTheme(b3_settings, SystemSettings.getSettings().getCurrentTheme() ) ;
        Theme.AppTheme(b2_showNotesList, SystemSettings.getSettings().getCurrentTheme() ) ;
        Theme.AppTheme(b1_ShowCategory, SystemSettings.getSettings().getCurrentTheme() ) ;
        Theme.AppTheme(Menu.getMenu(), SystemSettings.getSettings().getCurrentTheme() ) ;
    }*/

    public NoteButton[] getNoteButtons() {
        return noteButtons;
    }

    public void setNoteButtons(NoteButton[] noteButtons) {
        this.noteButtons = noteButtons;
    }

    public ClasorButton[] getCategoriesButtons() {
        return categoriesButtons;
    }

    public void setCategoriesButtons(ClasorButton[] categoriesButtons) {
        this.categoriesButtons = categoriesButtons;
    }

    public JLabel[] getNumberNotes() {
        return numberNotes;
    }

    public void setNumberNotes(JLabel[] numberNotes) {
        this.numberNotes = numberNotes;
    }

    public GridBagLayout getLayout_main() {
        if (Layout_main == null){
            Layout_main = new GridBagLayout();
        }
        return Layout_main;
    }

    public void setLayout_main(GridBagLayout Layout_main) {
        this.Layout_main = Layout_main;
    }
    
    public void addButtons(){
        noteButtons = new NoteButton[3];
        categoriesButtons = new ClasorButton[2];
        numberNotes = new JLabel[2];
        for (int index = 0; index < 3; index++){
            noteButtons[index] = new NoteButton("Not-" + (index + 1));
        }
        for (int index = 0; index < 2; index++){
            categoriesButtons[index] = new ClasorButton("Categories-1");
            numberNotes[index] = new JLabel("3");
        }
        for (int index = 0; index < 3; index++){
            Add.ADDCOMP(this, categoriesButtons[index], index, index, 1, 1, Add.getInsets(), GridBagConstraints.HORIZONTAL, 1.0, 0.0);
            Add.ADDCOMP(this, numberNotes[index], (index + 1), index, 1, 1, Add.getInsets(), GridBagConstraints.HORIZONTAL, 1.0, 0.0);
        }
        for (int index = 0; index < 1; index++){
            Theme.AppTheme(categoriesButtons[index], SystemSettings.getSettings().getCurrentTheme());
            Theme.AppTheme(numberNotes[index], SystemSettings.getSettings().getCurrentTheme());
        }
    }
    
    public void updateTheme(){
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme());
        for (int index = 0; index < 1; index++){
            Theme.AppTheme(categoriesButtons[index], SystemSettings.getSettings().getCurrentTheme());
            Theme.AppTheme(numberNotes[index], SystemSettings.getSettings().getCurrentTheme());
        }
        for (int index = 0; index < 3; index++){
            if(noteButtons[index] != null){
                Theme.AppTheme(noteButtons[index], SystemSettings.getSettings().getCurrentTheme());
            }
        }
    }

    public Actions getActOnOrganizer() {
        if(actOnOrganizer == null){
            actOnOrganizer = new Actions(this);
        }
        return actOnOrganizer;
    }

    public void setActOnOrganizer(Actions actOnOrganizer) {
        this.actOnOrganizer = actOnOrganizer;
    }
    
    
    
    
}
