package View;

import Base.DataBase;
import Base.SystemSettings;
import Control.Actions;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ListPanel extends JPanel{
    JButton denemee;
    GridBagLayout layout;
    FlowLayout internalLayout;
    JButton[] nameButtons, infs;
    JLabel[] L_dates, L_categories, L_cipherStatus;
    JLabel e;
    JCheckBoxMenuItem ChBoxMItem1_names, ChBoxMItem2_categories, ChBoxMItem3_dates, ChBoxMItem4_cipherStatus;
    JComponent names, categories, dates, cipherStatus;//ileride eklenebilir: tags (etiketlere göre listeleme)
    Actions listActions;
    
    public ListPanel(){
        layout = new GridBagLayout();
        this.setLayout(layout);
        Add.setAnchor(GridBagConstraints.LINE_START);
        Add.setInsets(3, 3, 3, 3);
        Add.ADDCOMP(this,getNamesComp(), 0, 0, 1, 1, Add.getInsets(), GridBagConstraints.VERTICAL, 1.0, 1.0);
        Add.ADDCOMP(this,getCategoriesComp(), 1, 0, 1, 1, Add.getInsets(), GridBagConstraints.VERTICAL, 1.0, 1.0);
        Add.ADDCOMP(this,getDatesComp(), 2, 0, 1, 1, Add.getInsets(), GridBagConstraints.VERTICAL, 1.0, 1.0);
        Add.ADDCOMP(this,getCipherStatusComp(), 3, 0, 1, 1, Add.getInsets(), GridBagConstraints.VERTICAL, 1.0, 1.0);
        Add.setInsets(3, 3, 3, 3);
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme());
        MainFrame.getFrame_Main().setVisible(true);
        
    }
    
    public JComponent getNamesComp(){
        if (names == null){
            names = new JComponent() {};
            names.setLayout(getCompLayout());
            names.setPreferredSize(new Dimension(70, 180));
            names.add(getChBoxMItem1_names());//Burada daha iyi yöntemler olabilir; araştır!
            for (int index = 0; index < getNameButtons().length; index++){//Bu işlem ile getNameButtons() fonksiyonundaki işlemler aynı fonksiyonda yapılırsa daha verimli olabilir; bu durumun zararı olur mu, araştır.
                names.add(getNameButtons()[index]);
            }
/*DENEME            names.add(new JButton("Yazı"));
            names.add(new JButton("Yazı2"));
            names.add(new JButton("Yazı3"));
            names.add(new JButton("Yazı4"));
            names.add(new JButton("Yazı5"));
            names.add(new JButton("Yazı6"));*/
        }
        return names;
    }

    public void setNamesComp(JComponent names){
        this.names = names;
    }

    public JComponent getCategoriesComp() {
        if (categories == null){
            categories = new JComponent() {};
            categories.setLayout(getCompLayout());
            categories.setPreferredSize(new Dimension(140, 180));
            categories.add(getChBoxMItem2_categories());
            for (int index = 0; index < getL_categories().length; index++){
                categories.add(getL_categories()[index]);
            }
/*DENEME            categories.add(new JButton("Yazı"));
            categories.add(new JButton("Yazı2"));
            categories.add(new JButton("Yazı3"));
            categories.add(new JButton("Yazı4"));
            categories.add(new JButton("Yazı5"));
            categories.add(new JButton("Yazı6"));*/
        }
        return categories;
    }

    public void setCategoriesComp(JComponent categories) {
        this.categories = categories;
    }
    
    public JComponent getDatesComp() {
        if (dates == null){
            dates = new JComponent() {};
            dates.setLayout(getCompLayout());
            dates.setPreferredSize(new Dimension(140, 180));
            dates.add(getChBoxMItem3_dates());
            for (int index = 0; index < getL_dates().length; index++){
                dates.add(getL_dates()[index]);
            }
/*DENEME            dates.add(new JButton("Yazı"));
            dates.add(new JButton("Yazı2"));
            dates.add(new JButton("Yazı3"));
            dates.add(new JButton("Yazı4"));
            dates.add(new JButton("Yazı5"));
            dates.add(new JButton("Yazı6"));*/
        }
        return dates;
    }

    public void setDatesComp(JComponent dates) {
        this.dates = dates;
    }

    public JComponent getCipherStatusComp() {
        if (cipherStatus == null){
            cipherStatus = new JComponent() {};
            cipherStatus.setLayout(getCompLayout());
            cipherStatus.setPreferredSize(new Dimension(140, 180));
            cipherStatus.add(getChBoxMItem4_cipherStatus());
            for (int index = 0; index < getL_cipherStatus().length; index++){
                cipherStatus.add(getL_cipherStatus()[index]);
            }
/*DENEME            JButton ewew = new JButton("Özel");
            ewew.setPreferredSize(new Dimension ((int) cipherStatus.getPreferredSize().getWidth(), 25));//Bütün ayarlar cipherStatus'tan alınabilir
            cipherStatus.add(ewew);
            cipherStatus.add(new JButton("Yazı"));
            cipherStatus.add(new JButton("Yazı2"));
            cipherStatus.add(new JButton("Yazı3"));
            cipherStatus.add(new JButton("Yazı4"));
            cipherStatus.add(new JButton("Yazı5"));
            cipherStatus.add(new JButton("Yazı6"));*/
        }
        return cipherStatus;
    }

    public void setCipherStatusComp(JComponent cipherStatus) {
        this.cipherStatus = cipherStatus;
    }

    public JCheckBoxMenuItem getChBoxMItem1_names() {
        if (ChBoxMItem1_names == null){
            ChBoxMItem1_names = new JCheckBoxMenuItem("İsim", false);
        }
        return ChBoxMItem1_names;
    }

    public void setChBoxMItem1_names(JCheckBoxMenuItem ChBoxMItem1_names) {
        ChBoxMItem1_names = ChBoxMItem1_names;
    }

    public JCheckBoxMenuItem getChBoxMItem2_categories() {
        if (ChBoxMItem2_categories == null){
            ChBoxMItem2_categories = new JCheckBoxMenuItem("Kategori ismi", false);
        }
        return ChBoxMItem2_categories;
    }

    public void setChBoxMItem2_categories(JCheckBoxMenuItem ChBoxMItem2_categories) {
        ChBoxMItem2_categories = ChBoxMItem2_categories;
    }

    public JCheckBoxMenuItem getChBoxMItem3_dates() {
        if (ChBoxMItem3_dates == null){
            ChBoxMItem3_dates = new JCheckBoxMenuItem("Düzenlenme tarihi", false);
        }
        return ChBoxMItem3_dates;
    }

    public void setChBoxMItem3_dates(JCheckBoxMenuItem ChBoxMItem3_dates) {
        ChBoxMItem3_dates = ChBoxMItem3_dates;
    }

    public JCheckBoxMenuItem getChBoxMItem4_cipherStatus() {
        if (ChBoxMItem4_cipherStatus == null){
            ChBoxMItem4_cipherStatus = new JCheckBoxMenuItem("Şifrelenme durumu", false);
        }
        return ChBoxMItem4_cipherStatus;
    }

    public void setChBoxMItem4_cipherStatus(JCheckBoxMenuItem ChBoxMItem4_cipherStatus) {
        ChBoxMItem4_cipherStatus = ChBoxMItem4_cipherStatus;
    }
    
    public FlowLayout getCompLayout(){
        if(internalLayout == null){
            internalLayout = new FlowLayout(FlowLayout.LEADING, 3, 3);
        }
        return internalLayout;
    }

    public Actions getListActions() {
        if (listActions == null){
            listActions = new Actions(this);
        }
        return listActions;
    }

    public void setListActions(Actions listActions) {
        listActions = listActions;
    }

    public JButton[] getNameButtons() {
        if (nameButtons == null){
            Dimension optimum = new Dimension((int) names.getPreferredSize().getWidth(), 25);
            String[] noteNames = DataBase.getDatabase().getNotesNames();
            for (int index = 0; index < noteNames.length; index++){
                nameButtons = new JButton[noteNames.length];
                nameButtons[index] = new JButton(noteNames[index]);
                nameButtons[index].setPreferredSize(optimum);
                nameButtons[index].addActionListener(getListActions());
                Theme.AppTheme(nameButtons[index], SystemSettings.getSettings().getCurrentTheme());
            }
        }
        return nameButtons;
    }

    public void setNameButtons(JButton[] nameButtons) {
        this.nameButtons = nameButtons;
    }

    public JLabel[] getL_dates() {
        if (L_dates == null){
            Dimension optimum = new Dimension((int) dates.getPreferredSize().getWidth(), 25);
            Date[] changingDates = DataBase.getDatabase().getNotesProduceDates();//Bu şekilde kullanmak mı, yoksa her defasında DataBase'in getDataBase'ine erişerek kullanmak mı daha iyi?
            changingDates.toString();
            L_dates = new JLabel[changingDates.length];
            for (int index = 0; index < L_dates.length; index++){
                L_dates[index] = new JLabel(changingDates[index].toString());//Tarihi yazı şeklinde almak istiyorum; burası denetlenecek inşâAllâh
                L_dates[index].setPreferredSize(optimum);
                Theme.AppTheme(L_dates[index], SystemSettings.getSettings().getCurrentTheme());
            }
        }
        return L_dates;
    }

    public void setL_dates(JLabel[] L_dates) {
        this.L_dates = L_dates;
    }

    public JLabel[] getL_categories() {
        if(L_categories == null){
            Dimension optimum = new Dimension((int) categories.getPreferredSize().getWidth(), 25);
            String[] categoryStrings = DataBase.getDatabase().getCategoryNames();
            L_categories = new JLabel[categoryStrings.length];
            for (int index = 0; index < categoryStrings.length; index++){
                L_categories[index] = new JLabel(categoryStrings[index]);
                L_categories[index].setPreferredSize(optimum);
                Theme.AppTheme(L_categories[index], SystemSettings.getSettings().getCurrentTheme());
            }
        }
        return L_categories;
    }

    public void setL_categories(JLabel[] L_categories) {
        this.L_categories = L_categories;
    }
//AŞAĞIDAKİ FONKSİYON DEĞİŞTİRİLMELİ
    public JLabel[] getL_cipherStatus() {
        if (L_cipherStatus == null){
            Dimension optimum = new Dimension((int) cipherStatus.getPreferredSize().getWidth(), 25);
            String[] cipherStatusStrings = DataBase.getDatabase().getNotesNames();//Burası değiştirilmeli
            L_cipherStatus = new JLabel[cipherStatusStrings.length];
            for (int index = 0; index < cipherStatusStrings.length; index++){
                L_cipherStatus[index] = new JLabel(cipherStatusStrings[index]);
                L_cipherStatus[index].setPreferredSize(optimum);
                Theme.AppTheme(L_cipherStatus[index], SystemSettings.getSettings().getCurrentTheme());
            }
        }
        return L_cipherStatus;
    }

    public void setL_cipherStatus(JLabel[] L_cipherStatus) {
        this.L_cipherStatus = L_cipherStatus;
    }
    
    
    
}
