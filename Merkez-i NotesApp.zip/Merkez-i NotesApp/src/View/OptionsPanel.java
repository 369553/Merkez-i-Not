package View;
//Add.setInsets(70, 70, 70, 70);Ekran büyüdüğünde insets ler de ona göre ayarlanmalı; yânî containerListener kullanılmalı
import Base.SystemSettings;
import Control.ActOnOptions;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class OptionsPanel extends JPanel{
    JLabel L1_language, L2_log, L3_logLocation, L4_theme, L5_autosave;
    JCheckBox CheckB1_isLogging, CheckB2_isAutosave ;
    JComboBox ComB1_language, ComB2_theme ;
    JButton B1_chooseLocation, B2_save ;
    GridBagLayout layout;
    JFileChooser chooser;
    ActOnOptions acts; 
    
    public OptionsPanel(){
        layout = new GridBagLayout();
        this.setLayout(layout);
        Add.setInsets(7, 7, 7, 7);
        Add.setAnchor(GridBagConstraints.CENTER);
        Add.ADDCOMP(this, getL1_language(), 0, 0, 1, 1, Add.getInsets(), GridBagConstraints.CENTER, 0.1, 0.1);
        Add.ADDCOMP(this, getComB1_language(), 1, 0, 1, 1, Add.getInsets(), GridBagConstraints.CENTER, 0.1, 0.1);
        Add.ADDCOMP(this, getL2_log(), 0, 1, 1, 1, Add.getInsets(), GridBagConstraints.CENTER, 0.1, 0.1);
        Add.ADDCOMP(this, getCheckB1_isLogging(), 1, 1, 1, 1, Add.getInsets(), GridBagConstraints.CENTER, 0.1, 0.1);
        Add.ADDCOMP(this, getL3_logLocation(), 0, 2, 1, 1, Add.getInsets(), GridBagConstraints.CENTER, 0.1, 0.1);
        Add.ADDCOMP(this, getB1_chooseLocation(), 1, 2, 1, 1, Add.getInsets(), GridBagConstraints.CENTER, 0.1, 0.1);
        Add.ADDCOMP(this, getL4_theme(), 0, 3, 1, 1, Add.getInsets(), GridBagConstraints.CENTER, 0.1, 0.1);
        Add.ADDCOMP(this, getComB2_theme(), 1, 3, 1, 1, Add.getInsets(), GridBagConstraints.CENTER, 0.1, 0.1);
        Add.ADDCOMP(this, getL5_autosave(), 0, 4, 1, 1, Add.getInsets(), GridBagConstraints.CENTER, 0.1, 0.1);
        Add.ADDCOMP(this, getCheckB2_isAutosave(), 1, 4, 1, 1, Add.getInsets(), GridBagConstraints.CENTER, 0.1, 0.1);
        Add.ADDCOMP(this, getB2_save(), 0, 5, 1, 1, Add.getInsets(), GridBagConstraints.CENTER, 0.1, 0.1);
        Add.setInsets(70, 70, 70, 70);
        //this.setPreferredSize(new Dimension(307, 250));
        //this.setMaximumSize(new Dimension(307, 250));
        //this.setMinimumSize(new Dimension(307, 250));
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme());
        MainFrame.getFrame_Main().setVisible(true);
//        System.err.println("panel boyutu:" + MainFrame.getFrame_Main().getWidth() + "," +MainFrame.getFrame_Main().getHeight());
    }

    public JLabel getL1_language() {
        if (L1_language == null){
            L1_language = new JLabel("Dil:");
            Theme.AppTheme(L1_language, SystemSettings.getSettings().getCurrentTheme());
        }
        return L1_language;
    }

    public void setL1_language(JLabel L1_language) {
        this.L1_language = L1_language;
    }

    public JLabel getL2_log() {
        if (L2_log == null){
            L2_log = new JLabel("Kayıt tut:");
            Theme.AppTheme(L2_log, SystemSettings.getSettings().getCurrentTheme());
        }
        return L2_log;
    }

    public void setL2_log(JLabel L2_log) {
        this.L2_log = L2_log;
    }

    public JLabel getL3_logLocation() {//not ve kayıtların onumu her zaman seçilebilr olmalı ve default değeri olmalı
        if (L3_logLocation == null){
            L3_logLocation = new JLabel("Not ve kayıtların konumu:");
            Theme.AppTheme(L3_logLocation, SystemSettings.getSettings().getCurrentTheme());
        }
        return L3_logLocation;
    }

    public void setL3_logLocation(JLabel L3_logLocation) {
        this.L3_logLocation = L3_logLocation;
    }

    public JLabel getL4_theme() {
        if (L4_theme == null){
            L4_theme = new JLabel("Tema:");
            Theme.AppTheme(L4_theme, SystemSettings.getSettings().getCurrentTheme());
        }
        return L4_theme;
    }

    public void setL4_theme(JLabel L4_theme) {
        this.L4_theme = L4_theme;
    }

    public JLabel getL5_autosave() {
        if (L5_autosave == null){
            L5_autosave = new JLabel("Otomatik kaydet:");
            Theme.AppTheme(L5_autosave, SystemSettings.getSettings().getCurrentTheme());
        }
        return L5_autosave;
    }

    public void setL5_autosave(JLabel L5_autosave) {
        this.L5_autosave = L5_autosave;
    }

    public JCheckBox getCheckB1_isLogging() {
        if (CheckB1_isLogging == null){
            CheckB1_isLogging = new JCheckBox();
            Theme.AppTheme(CheckB1_isLogging, SystemSettings.getSettings().getCurrentTheme());
        }
        return CheckB1_isLogging;
    }

    public void setCheckB1_isLogging(JCheckBox CheckB1_isLogging) {
        this.CheckB1_isLogging = CheckB1_isLogging;
    }

    public JCheckBox getCheckB2_isAutosave() {
        if (CheckB2_isAutosave == null){
            CheckB2_isAutosave = new JCheckBox();
            Theme.AppTheme(CheckB2_isAutosave, SystemSettings.getSettings().getCurrentTheme());
        }
        return CheckB2_isAutosave;
    }

    public void setCheckB2_isAutosave(JCheckBox CheckB2_isAutosave) {
        this.CheckB2_isAutosave = CheckB2_isAutosave;
    }

    public JComboBox getComB1_language() {
        if (ComB1_language == null){
            ComB1_language = new JComboBox(new String[]{"TÜRKÇE"});//DATABASE'den AL
            ComB1_language.setPreferredSize(new Dimension(100, 25));
            Theme.AppTheme(ComB1_language, SystemSettings.getSettings().getCurrentTheme());
        }
        return ComB1_language;
    }

    public void setComB1_language(JComboBox ComB1_language) {
        this.ComB1_language = ComB1_language;
    }

    public JComboBox getComB2_theme() {
        if (ComB2_theme == null){
            ComB2_theme = new JComboBox();
            ComB2_theme.setPreferredSize(new Dimension(100, 25));
            ComB2_theme.setModel( getcolormodel() ) ;
            ComB2_theme.setFont(new Font("Times New Roman", Font.BOLD, 13));
            ComB2_theme.setRenderer(new ListCellRender() ) ;
            ComB2_theme.setSelectedIndex(0);
            Theme.AppTheme(ComB2_theme, SystemSettings.getSettings().getCurrentTheme());
        }
        return ComB2_theme;
    }

    public void setComB2_theme(JComboBox ComB2_theme) {
        this.ComB2_theme = ComB2_theme;
    }

    public JButton getB1_chooseLocation() {
        if(B1_chooseLocation == null){
            B1_chooseLocation = new JButton("Gözat");
            B1_chooseLocation.setPreferredSize(new Dimension(100, 25));
            B1_chooseLocation.addActionListener( getActs() ) ;
            Theme.AppTheme(B1_chooseLocation, SystemSettings.getSettings().getCurrentTheme());
        }
        return B1_chooseLocation;
    }

    public void setB1_chooseLocation(JButton B1_chooseLocation) {
        this.B1_chooseLocation = B1_chooseLocation;
    }

    public JButton getB2_save() {
        if(B2_save == null){
            B2_save = new JButton("KAYDET");
            B2_save.setPreferredSize(new Dimension(100, 25));
            B2_save.addActionListener( getActs() ) ;
            Theme.AppTheme(B2_save, SystemSettings.getSettings().getCurrentTheme());
        }
        return B2_save;
    }

    public void setB2_save(JButton B2_save) {
        this.B2_save = B2_save;
    }
    
    DefaultComboBoxModel getcolormodel(){
        DefaultComboBoxModel model= new DefaultComboBoxModel();
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/01Standard.png")),"Standard"));
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/02Caramel.png")),"Caramel"));
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/03Blue.png")),"Blue"));
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/04Purple.png")),"Purple"));
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/05Red.png")),"Red"));
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/06Gold.png")),"Gold"));
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/07Special.png")),"Special"));
        model.addElement(new ColorInf(new ImageIcon(getClass().getResource("Themes_icons/08Dark.png")),"Dark"));
        return model;
}

    public JFileChooser getChooser() {
        if(chooser == null){
            String current_path = "/Desktop";//????
            chooser = new JFileChooser( current_path ) ;
            chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            chooser.addActionListener( getActs() ) ;
            chooser.setAcceptAllFileFilterUsed( false ) ;
            Theme.AppTheme(chooser, SystemSettings.getSettings().getCurrentTheme() );
        }
        return chooser;
    }

    public void setChooser(JFileChooser chooser) {
        this.chooser = chooser;
    }
    
    public void openChooser () {
        getChooser().showDialog(this, "Klasörü seç" ) ;
    }

    public ActOnOptions getActs() {
        if(acts == null){
            acts = new ActOnOptions(this);
        }
        return acts;
    }

    public void setActs(ActOnOptions acts) {
        this.acts = acts;
    }
    
    public void updateTheme(){
        Theme.AppTheme(chooser, SystemSettings.getSettings().getCurrentTheme() );
        Theme.AppTheme(B2_save, SystemSettings.getSettings().getCurrentTheme());
        Theme.AppTheme(B1_chooseLocation, SystemSettings.getSettings().getCurrentTheme());
        Theme.AppTheme(ComB2_theme, SystemSettings.getSettings().getCurrentTheme());
        Theme.AppTheme(ComB1_language, SystemSettings.getSettings().getCurrentTheme());
        Theme.AppTheme(CheckB2_isAutosave, SystemSettings.getSettings().getCurrentTheme());
        Theme.AppTheme(CheckB1_isLogging, SystemSettings.getSettings().getCurrentTheme());
        Theme.AppTheme(L5_autosave, SystemSettings.getSettings().getCurrentTheme());
        Theme.AppTheme(L4_theme, SystemSettings.getSettings().getCurrentTheme());
        Theme.AppTheme(L3_logLocation, SystemSettings.getSettings().getCurrentTheme());
        Theme.AppTheme(L2_log, SystemSettings.getSettings().getCurrentTheme());
        Theme.AppTheme(L1_language, SystemSettings.getSettings().getCurrentTheme());
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme());
        
    }
    
    
}
