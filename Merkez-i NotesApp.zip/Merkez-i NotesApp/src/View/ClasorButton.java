package View;

import javax.swing.JButton;

public class ClasorButton extends JButton{
    ClasorIcon icon;
    
    public ClasorButton(String text){
        super(text);
    }
    
    public ClasorButton(String text, int iconID){
    //    this.icon = new ClasorIcon(iconID);
    //    super(text, icon);
    }
    
}
