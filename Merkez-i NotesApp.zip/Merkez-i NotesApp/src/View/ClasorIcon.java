package View;

import javax.swing.ImageIcon;
//FILL
public class ClasorIcon extends ImageIcon{
    ImageIcon icon;
    int id;
    
    public ClasorIcon (int icon_ID) {
//        this.icon = new ImageIcon( DataBase...(icon_ID));
    }
}
