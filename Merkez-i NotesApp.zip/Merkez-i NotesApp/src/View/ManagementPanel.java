package View;

import Base.SystemSettings;
import Control.Actions;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;

public class ManagementPanel extends JPanel{
    JButton[] clasors_and_notes;
    NoteButton B1_deneme;
    Actions action_in_managPanel;
    FlowLayout layout;
    
    public ManagementPanel(){
        this.setLayout(getPanelLayout());
        this.add(getB1deneme());
        //addClasor_and_notes();
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme() ) ;
        MainFrame.getFrame_Main().setVisible(true);
    }

    public FlowLayout getPanelLayout() {
        if (layout == null){
            layout = new FlowLayout(FlowLayout.LEADING, 10, 10);
        }
        return layout;
    }

    public void setPanelLayout(FlowLayout layout) {
        this.layout = layout;
    }
    
    public NoteButton getB1deneme(){
        if (B1_deneme == null){
            B1_deneme = new NoteButton("NOT-1");
            B1_deneme.setPreferredSize(new Dimension(150,150));
            B1_deneme.addActionListener(getAction_in_managPanel());
            Theme.AppTheme( B1_deneme, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return B1_deneme;
    }

    /*public JButton[] getClasors_and_notes() {
        if (clasors_and_notes == null){
            clasors_and_notes = new JButton[15];
            for (int i = 0; i < clasors_and_notes.length; i++){
                clasors_and_notes[i] = new JButton((i+1) + ". buton");
                clasors_and_notes[i].setPreferredSize(new Dimension(150,150));
                clasors_and_notes[i].addActionListener(getAction_in_managPanel());
                Theme.AppTheme( clasors_and_notes[i], SystemSettings.getSettings().getCurrentTheme() ) ;
            }
        }
        return clasors_and_notes;
    }

    public void setClasors_and_notes(JButton[] clasors_and_notes) {
        this.clasors_and_notes = clasors_and_notes;
    }
    
    public void addClasor_and_notes(){
        for (int i = 0; i < getClasors_and_notes().length; i++){
            this.add(clasors_and_notes[i]);
//            Add.ADDCOMP(this, clasors_and_notes[i], GridBagConstraints.RELATIVE, (4-i), 1, 1, Add.getInsets(), GridBagConstraints.NONE, 1.0, 1.0);
        }
    }*/

    public Actions getAction_in_managPanel() {
        if (action_in_managPanel == null){
            action_in_managPanel = new Actions(this);
        }
        return action_in_managPanel;
    }

    public void setAction_in_managPanel(Actions action_in_managPanel) {
        this.action_in_managPanel = action_in_managPanel;
    }
    
    public void updateTheme(){
        Theme.AppTheme( B1_deneme, SystemSettings.getSettings().getCurrentTheme() ) ;
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme() ) ;
    }
    
}
