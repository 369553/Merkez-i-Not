package View;

import javax.swing.Icon;

public class ColorInf {
    Icon a;
    String b;
    
    ColorInf (Icon a,String b){
        this.a=a;
        this.b=b;
    }
    
    public Icon getA() {
        return a;
    }

    public void setA(Icon a) {
        this.a = a;
    }

    public String getB() {
        return b;
    }

    public void setB(String b) {
        this.b = b;
    }
}
