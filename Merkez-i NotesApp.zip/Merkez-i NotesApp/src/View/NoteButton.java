package View;

import Base.SystemSettings;
import java.awt.Color;
import javax.swing.JButton;

public class NoteButton extends JButton{
    NoteIcon icon;
    
    public NoteButton(String text, int IconID){
        //super(text, icon);
    }
    
    public NoteButton(String text){
        //super("Not-1", icon);
        super(text);
    }
    
    
}
