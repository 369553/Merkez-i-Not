package View;

import java.awt.Image;
import javax.swing.ImageIcon;

public class NoteIcon extends ImageIcon{
    int id;
    Image image;
    
    public NoteIcon(int id){
        //image = new Image
        //super(image, "Karakter sayısı olabilir");
    }
    
}
