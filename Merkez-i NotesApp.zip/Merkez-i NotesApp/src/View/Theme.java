package View;
//Theme ya font vs. de eklenebilir
import java.awt.Color;
import java.awt.Component;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Theme {
    String ThemeName, BackgroundColor, ButtonColor, TextColor, ButtonTextColor, SecondPanelBackgroundColor, NotingAreaColor, NotingAreaTextColor;

    public Theme (String ThemeName){
        String[] temp;
        this.ThemeName = ThemeName ;
        temp = exportInf ( ThemeName ) ;
        this.ThemeName = temp[0];
        this.BackgroundColor = temp[1];
        this.ButtonColor = temp[2];
        this.TextColor = temp[3];
        this.ButtonTextColor = temp[4];
        this.SecondPanelBackgroundColor = temp[5];
        this.NotingAreaColor = temp[6];
        this.NotingAreaTextColor = temp[7];
        // find this method : delete(temp);
    }

    public String getThemeName() {
        return ThemeName;
    }

    public void setThemeName(String ThemeName) {
        this.ThemeName = ThemeName;
    }
    
    public String getBackgroundColor() {
        return BackgroundColor;
    }

    public void setBackgroundColor(String BackgroundColor) {
        this.BackgroundColor = BackgroundColor;
    }

    public String getButtonColor() {
        return ButtonColor;
    }

    public void setButtonColor(String ButtonColor) {
        this.ButtonColor = ButtonColor;
    }

    public String getTextColor() {
        return TextColor;
    }

    public void setTextColor(String TextColor) {//BLUE : 3b90e6, 7d99b4, 4a6784,a4c7da
        this.TextColor = TextColor;//HAFİF KIRMIZI: c7b0a0
    }

    public String getButtonTextColor() {
        return ButtonTextColor;
    }

    public void setButtonTextColor(String ButtonTextColor) {
        this.ButtonTextColor = ButtonTextColor;
    }

    public String getSecondPanelBackgroundColor() {
        return SecondPanelBackgroundColor;
    }

    public void setSecondPanelBackgroundColor(String SecondPanelBackgroundColor) {
        this.SecondPanelBackgroundColor = SecondPanelBackgroundColor;
    }

    public String getNotingAreaColor() {
        return NotingAreaColor;
    }

    public void setNotingAreaColor(String NotingAreaColor) {
        this.NotingAreaColor = NotingAreaColor;
    }

    public String getNotingAreaTextColor() {
        return NotingAreaTextColor;
    }

    public void setNotingAreaTextColor(String NotingAreaTextColor) {
        this.NotingAreaTextColor = NotingAreaTextColor;
    }
    
    
    
    //Check and FIX
    public String[] exportInf ( String ThemeName ) {
        switch ( ThemeName ) {
          /* TAMAM = Standard */case "Standard": return new String[] {new String("Standard"), new String("#F5F5DC"), new String("#c0c0c0"), new String("#7B3F00"), new String("#800000"), new String("#c0c0c0"), new String("#a9c0e7"), new String("#0d213a")};
          /*TAMAM = Caramel*/  case "Caramel": return new String[] {new String("Caramel"), new String("#D2691E"), new String("#F5F5DC"), new String("#F5F5DC"), new String("#116062"), new String("#7B3F00"), new String("#f2ba80"), new String("#4e2800")};//7B3F00,07111a
          /*TAMAM = Blue*/   case "Blue": return new String[] {new String("Blue"), new String("#3b90e6"), new String("#dbe8f6"), new String("#e9a5a5"), new String("#800000"), new String("#0766c9"), new String("#c4ebf7"), new String("#091a34")};//Blue
          /*TAMAM = Purple*/  case "Purple": return new String[] {new String("Purple"), new String("#ff84c1"), new String("#FBA0E3"), new String("#064343"), new String("#116062"), new String("#c0c0c0"), new String("#e18efc"), new String("#380a47")};
          /*TAMAM = Red*/ case "Red": return new String[] {new String("Red"), new String("#f34d59"), new String("#f38e59"), new String("#bacced"), new String("#363b9d"), new String("#702333"), new String("#fe8195"), new String("#460233")};
          /*TAMAM = Gold*/ case "Gold": return new String[] {new String("Gold"), new String("#F0DC82"), new String("#ffd700"), new String("#7B3F00"), new String("#800000"), new String("#f4bc67"), new String("#bbeea3"), new String("#74364b")};
          /*TAMAM = Special*/ case "Special": return new String[] {new String("Special"), new String("#007FFF"), new String("#DC143C"), new String("#ffbc67"), new String("#F5F5DC"), new String("#a85757"), new String("#99cbfe"), new String("#702333")};
          /*TAMAM = Dark*/ case "Dark": return new String[] {new String("Dark"), new String("#2a3341"), new String("#5a88cb"), new String("#c0c0c0"), new String("#F5F5DC"), new String("#674444"), new String("#818589"), new String("#aad1f8")};
            default: return new String[] {new String("Standard"), new String("#F5F5DC"), new String("#c0c0c0"), new String("#7B3F00"), new String("#800000"), new String("#c0c0c0"), new String("#a9c0e7"), new String("#0d213a")};
            
        }
    }//Check and FIX
        public static void AppTheme ( Component material, Theme theme ) {
            if ( material.getClass().getName().contains( "JLabel" ) ) {
                material.setForeground(Color.decode ( theme.getTextColor() ) ) ;
            }
            else if ( material.getClass().getName().contains( "JButton" ) ) {
                material.setBackground( Color.decode( theme.getButtonColor() ) ) ;
                material.setForeground( Color.decode( theme.getButtonTextColor()) ) ;
            }
            else if ( material.getClass().getName().contains( "JComboBox" ) ) {
                material.setBackground( Color.decode( theme.getButtonColor() ) ) ;
                material.setForeground( Color.decode( theme.getButtonTextColor()) ) ;
            }
            else if ( material.getClass().getName().contains( "JTextArea" ) ) { 
                JTextArea textArea = (JTextArea) material ;
                textArea.setBackground( Color.decode (theme.getNotingAreaColor()) ) ;
                textArea.setForeground( Color.decode ( theme.getNotingAreaTextColor()) ) ;
                textArea.setSelectionColor( Color.decode(theme.getButtonTextColor()) ) ;
                textArea.setSelectedTextColor( Color.decode( theme.getBackgroundColor() ) ) ;
                textArea.setCaretColor(Color.decode(theme.getTextColor()));
            }
            else if ( material.getClass().getName().contains( "JTextField" ) ){
                JTextField texField = (JTextField) material ;
                texField.setBackground( Color.decode (theme.getNotingAreaColor() ) ) ;
                texField.setForeground( Color.decode ( theme.getNotingAreaTextColor() ) ) ;
                texField.setSelectionColor( Color.decode(theme.getBackgroundColor()) ) ;
                texField.setSelectedTextColor( Color.decode( theme.getButtonTextColor() ) ) ;
                texField.setCaretColor(Color.decode(theme.getBackgroundColor()));
            }
            else if (material.getClass().getName().contains("NoteButton")){
                NoteButton noteButton = (NoteButton) material;
                noteButton.setBackground(Color.decode(theme.getButtonColor()));
                noteButton.setForeground(Color.decode(theme.getButtonTextColor()));
            }
            else if (material.getClass().getName().contains("ClasorButton")){
                ClasorButton categoryButton = (ClasorButton) material;
                categoryButton.setBackground(Color.decode(theme.getButtonColor()));
                categoryButton.setForeground(Color.decode(theme.getButtonTextColor()));
            }
            else if ( /*material.getClass().getName().contains( "EditTools") ||*/ material.getClass().getName().contains("Menu")) {
                material.setBackground( Color.decode( theme.getSecondPanelBackgroundColor() ) ) ;
            }
            else /*if ( material.getClass().getName().contains( "JCheckBox" ) )*/ {/*(material.getClass().getName().contains( "Jpanel" ) )*/
                material.setBackground( Color.decode( theme.getBackgroundColor() ) ) ;
            }
        }
    
    
}