package View;

import Base.SystemSettings;
import Control.MovementOnKeyboard;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class EditingPanel extends JPanel{
    private static EditingPanel editPanel;
    protected GridBagLayout layout;
    EditTools editTools;
    JTextArea TextArea_writingArea;
    MovementOnKeyboard catchKey;
    
    public EditingPanel() {
        layout = new GridBagLayout();
        this.setLayout(layout);
        //notte = new JTextArea("Bismillâh", 30, 30);
        Add.setInsets(3, 3, 3, 3);
        Add.setAnchor(GridBagConstraints.LINE_START);
        Add.ADDCOMP(this, getEditTools(), 0, 0, 2, 1, Add.getInsets(), GridBagConstraints.HORIZONTAL, 1.0, 0.0);
        Add.setAnchor(GridBagConstraints.CENTER);
        Add.ADDCOMP(this, getTextArea_writingArea(), 0, 1, 2, 1, Add.getInsets(), GridBagConstraints.BOTH, 1.0, 1.0);
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme() ) ;
        MainFrame.getFrame_Main().setVisible(true);
    }

    public EditTools getEditTools() {
        if (editTools == null){
            editTools = EditTools.getEditTools();
        }
        return editTools;
    }

    public void setEditTools(EditTools editTools) {
        this.editTools = editTools;
    }

    public JTextArea getTextArea_writingArea() {
        if (TextArea_writingArea == null){
            TextArea_writingArea = new JTextArea("Bismillâh", 30, 30);
            TextArea_writingArea.setFont(new Font("Times New Roman", Font.ITALIC, 16));
            TextArea_writingArea.setAutoscrolls(true);
            Theme.AppTheme(TextArea_writingArea, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return TextArea_writingArea;
    }

    public void setTextArea_writingArea(JTextArea TextArea_writingArea) {
        this.TextArea_writingArea = TextArea_writingArea;
    }

    public static EditingPanel getEditPanel() {
        if (editPanel == null){
            editPanel = new EditingPanel();
        }
        return editPanel;
    }

    public static void setEditPanel(EditingPanel editPanel) {
        EditingPanel.editPanel = editPanel;
    }

    public MovementOnKeyboard getCatchKey() {
        if(catchKey == null){
            catchKey = new MovementOnKeyboard(this);
        }
        return catchKey;
    }

    public void setCatchKey(MovementOnKeyboard catchKey) {
        this.catchKey = catchKey;
    }
    
    public void addListeners(){
        //EditingPanel.getEditPanel().getTextArea_writingArea().addKeyListener(getCatchKey());
    }
    
    public void updateTheme(){
        Theme.AppTheme(TextArea_writingArea, SystemSettings.getSettings().getCurrentTheme() ) ;
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme() ) ;
        getEditTools().updateTheme();
    }
    
}
