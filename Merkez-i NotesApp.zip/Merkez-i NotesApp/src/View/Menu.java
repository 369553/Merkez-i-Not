package View;

import Base.SystemSettings;
import Control.MenuActions;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
//Menunun pozisyonunu değiştirme eklenebilir
public class Menu extends JPanel{//ayarlar, category, sırasıyla notlar, yedekleme merkezi, icon, isim
    private static Menu menu;
    private static JButton b1_ShowCategory, b2_showNotesList, b3_settings, b4_backuping;
    //ImageIcon icon;
    private static JLabel L1_name/*, L2_logoname*/;
    private static MenuActions menuActions;
    private static GridBagLayout L_Main;
     
    public Menu (){
     //   this.setLayout( null ) ;
        //this.setBounds(61, 11, 81, 140) ;
        this.setLayout( getL_Main() ) ;
//        Add.ADDCOMP(this, getIcon(), 0, 0, 0, 0, Add.getInsets(), GridBagConstraints.NONE);
        Add.setAnchor(GridBagConstraints.PAGE_START);
        Add.ADDCOMP(this, getL1_name(), 0, 0, 1, 1, Add.getInsets(), GridBagConstraints.NONE, 0.0, 1.0);
        Add.setAnchor(GridBagConstraints.CENTER);
        Add.ADDCOMP(this, getB1_ShowCategory(), 0, 1, 1, 1, Add.getInsets(), GridBagConstraints.NONE, 0.0, 0.0);
        Add.ADDCOMP(this, getB2_showNotesList(), 0, 2, 1, 1, Add.getInsets(), GridBagConstraints.NONE, 0.0, 0.0);
        Add.ADDCOMP(this, getB3_settings(), 0, 3, 1, 1, Add.getInsets(), GridBagConstraints.NONE, 0.0, 0.0);
        Add.setAnchor(GridBagConstraints.PAGE_END);
        Add.ADDCOMP(this, getB4_backuping(), 0, 4, 1, 1, Add.getInsets(), GridBagConstraints.NONE, 1.0, 1.0);
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme() ) ;
        MainFrame.getFrame_Main().setVisible(true);
    }
    
    public static GridBagLayout getL_Main() {
        if ( L_Main == null ) {
            L_Main = new GridBagLayout();
        }
        return L_Main;
    }
    
    public void setL_Main(GridBagLayout L_Main) {
        this.L_Main = L_Main;
    }

    public static JButton getB1_ShowCategory() {
        if (b1_ShowCategory == null){
            b1_ShowCategory = new JButton("Kategori görünümü");
            b1_ShowCategory.setPreferredSize(new Dimension(100, 25));
            Theme.AppTheme(b1_ShowCategory, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return b1_ShowCategory;
    }

    public void setB1_ShowCategory(JButton b1_ShowCategory) {
        this.b1_ShowCategory = b1_ShowCategory;
    }

    public static JButton getB2_showNotesList() {
        if (b2_showNotesList == null){
            b2_showNotesList = new JButton("Liste görünümü");
            b2_showNotesList.setPreferredSize(new Dimension(100, 25));
            Theme.AppTheme(b2_showNotesList, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return b2_showNotesList;
    }

    public void setB2_showNotesList(JButton b2_showNotesList) {
        this.b2_showNotesList = b2_showNotesList;
    }

    public static JButton getB3_settings() {
        if (b3_settings == null){
            b3_settings = new JButton("Ayarlar");
            b3_settings.setPreferredSize(new Dimension(100, 25));
            Theme.AppTheme(b3_settings, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return b3_settings;
    }

    public void setB3_settings(JButton b3_settings) {
        this.b3_settings = b3_settings;
    }

    public static JButton getB4_backuping() {
        if (b4_backuping == null){
            b4_backuping = new JButton("Yedekleyin");
            b4_backuping.setPreferredSize(new Dimension(100, 25));
            Theme.AppTheme(b4_backuping, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return b4_backuping;
    }

    public void setB4_backuping(JButton b4_backuping) {
        this.b4_backuping = b4_backuping;
    }

    public static JLabel getL1_name() {
        if (L1_name == null){
            L1_name = new JLabel("Giriş yapılmadı");
            Theme.AppTheme(L1_name, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return L1_name;
    }

    public void setL1_name(JLabel L1_name) {
        this.L1_name = L1_name;
    }
    
    public static Menu getMenu(){
        if (menu == null){
            menu = new Menu();
            menuActions = new MenuActions(menu);
            addingListener();
        }
        return menu;
    }

    public static MenuActions getMenuActions() {
        return menuActions;
    }

    public void setMenuActions(MenuActions menuActions) {
        this.menuActions = menuActions;
    }
    
    public static void addingListener(){
        getB1_ShowCategory().addActionListener(getMenuActions());
        getB2_showNotesList().addActionListener(getMenuActions());
        getB3_settings().addActionListener(getMenuActions());
        getB4_backuping().addActionListener(getMenuActions());
    }
    
    public void updateTheme(){//Fonksiyonların statik olup olmaması gerektiği, statik olmayan fonksiyondan statik bir şeye erişilmesinin ne demek olduğu ve bunun risk içerip içermediği hakkında araştırma yap
        Theme.AppTheme(L1_name, SystemSettings.getSettings().getCurrentTheme() ) ;
        Theme.AppTheme(b4_backuping, SystemSettings.getSettings().getCurrentTheme() ) ;
        Theme.AppTheme(b3_settings, SystemSettings.getSettings().getCurrentTheme() ) ;
        Theme.AppTheme(b2_showNotesList, SystemSettings.getSettings().getCurrentTheme() ) ;
        Theme.AppTheme(b1_ShowCategory, SystemSettings.getSettings().getCurrentTheme() ) ;
        Theme.AppTheme(Menu.getMenu(), SystemSettings.getSettings().getCurrentTheme() ) ;
    }
    
}
