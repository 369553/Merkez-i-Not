package View;

import Base.SystemSettings;
import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainView {
    MainPanel MP;
    
    public MainView () {
        getFrame_main().add( getMain_Panel(), BorderLayout.CENTER ) ;
        //getFrame_main().add( getSubMenu(), BorderLayout.NORTH);
//TUŞA BASILDIĞINDA AÇILMASI LAZIM        getFrame_main().add( getMenu(), BorderLayout.WEST);//konumu sağa alınabilir şekilde olabilir.
        getFrame_main().setVisible( true ) ;
        Theme.AppTheme(MainFrame.getFrame_Main(), SystemSettings.getSettings().getCurrentTheme() ) ;
    }
    
    
    public JFrame getFrame_main() {
        return MainFrame.getFrame_Main();
    }
    
    public JPanel getMain_Panel (){
        if (MP == null){
            MP = new MainPanel();
     //   Theme.AppTheme( MainPanel.getMain_Panel(), SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return MP;
    }
    
}
