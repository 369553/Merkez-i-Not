package View;

import Base.SystemSettings;
import Control.Actions;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
//Layout ve diğer ayarlamalar yapılacak
public class MainPanel extends JPanel{
    private GridBagLayout layout;
    private JButton B1_open_menu, B2_open_options, B3_backTo, B4_edit;
    protected Actions allActions;
    private ManagementPanel managPanel;
    private EditingPanel editPanel;
    private OptionsPanel optionsPanel;
    private ListPanel listPanel;
    
    public MainPanel () {//MenuActions ta ve Actions ta bu sınıfa göre çizilmiş nesnenin üçüncü elemanı kaldırılıyor: 11- open_menu, 2- open_options, 3-managPanel/optionsPanel/EditingPanel
        setLayout( getPanelLayout() ) ;
        Add.setAnchor(GridBagConstraints.FIRST_LINE_START);
        Add.ADDCOMP(this, getB1_open_menu(), 0, 0, 1, 1, Add.getInsets(), GridBagConstraints.NONE, 0.0, 0.0);
        Add.ADDCOMP(this, getB3_backTo(), 1, 0, 1, 1, Add.getInsets(), GridBagConstraints.NONE, 0.0, 0.0);
        Add.setAnchor(GridBagConstraints.FIRST_LINE_END);
        Add.ADDCOMP(this, getB4_edit(), 2, 0, 1, 1, Add.getInsets(), GridBagConstraints.NONE, 0.0, 0.0);
        Add.ADDCOMP(this, getB2_open_options(), 3, 0, 1, 1, Add.getInsets(), GridBagConstraints.NONE, 0.0, 0.0);
        Add.setAnchor(GridBagConstraints.CENTER);
        Add.ADDCOMP(this, getManagPanel(), 0, 1, 4, 1, Add.getInsets(), GridBagConstraints.BOTH, 1.0, 1.0);
//        Add.ADDCOMP(this, getEditPanel(), 0, 0, 1, 1, Add.getInsets(), GridBagConstraints.BOTH, 1.0, 1.0);
//        Add.ADDCOMP(this, getListPanel(), 0, 1, 2, 1, Add.getInsets(), GridBagConstraints.BOTH, 1.0, 1.0);
       Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme() ) ;
       
        
    }

    public ManagementPanel getManagPanel() {
        if (managPanel == null){
            managPanel = new ManagementPanel();
        }
        return managPanel;
    }

    public void setManagPanel(ManagementPanel managPanel) {
        this.managPanel = managPanel;
    }

    public EditingPanel getEditPanel() {
        if (editPanel == null){
            editPanel = EditingPanel.getEditPanel();
        }
        return editPanel;
    }

    public void setEditPanel(EditingPanel editPanel) {
        this.editPanel = editPanel;
    }
    
    public GridBagLayout getPanelLayout() {
        if ( layout == null ) {
            layout = new GridBagLayout();
        }
        return layout;
    }

    public JButton getB1_open_menu() {
        if (B1_open_menu == null){
            B1_open_menu = new JButton("M");
            B1_open_menu.setPreferredSize(new Dimension(50, 25));
            B1_open_menu.addActionListener(getAllActions());
            Theme.AppTheme( B1_open_menu, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return B1_open_menu;
    }

    public void setB1_open_menu(JButton B1_open_menu) {
        this.B1_open_menu = B1_open_menu;
    }

    public JButton getB2_open_options() {
        if (B2_open_options == null){
            B2_open_options = new JButton("<--");
            B2_open_options.addActionListener(getAllActions());
            Theme.AppTheme( B2_open_options, SystemSettings.getSettings().getCurrentTheme() ) ;
        }
        return B2_open_options;
    }

    public void setB2_open_options(JButton B2_open_options) {
        this.B2_open_options = B2_open_options;
    }

    public OptionsPanel getOptionsPanel() {
        if(optionsPanel == null){
            optionsPanel = new OptionsPanel();
        }
        return optionsPanel;
    }

    public void setOptionsPanel(OptionsPanel optionsPanel) {
        this.optionsPanel = optionsPanel;
    }

    public ListPanel getListPanel() {
        if(listPanel == null){
            listPanel = new ListPanel();
        }
        return listPanel;
    }

    public void setListPanel(ListPanel listPanel) {
        this.listPanel = listPanel;
    }

    public Actions getAllActions() {
        if (allActions == null){
            allActions = new Actions(this);
        }
        return allActions;
    }

    public void setAllActions(Actions allActions) {
        this.allActions = allActions;
    }

    public JButton getB3_backTo() {
        if(B3_backTo == null){
            B3_backTo = new JButton("<--");
            B3_backTo.addActionListener(getAllActions());
            Theme.AppTheme(B3_backTo, SystemSettings.getSettings().getCurrentTheme());
        }
        return B3_backTo;
    }

    public void setB3_backTo(JButton B3_backTo) {
        this.B3_backTo = B3_backTo;
    }

    public JButton getB4_edit() {
        if(B4_edit == null){
            B4_edit = new JButton("D");
            B4_edit.addActionListener(getAllActions());
            B4_edit.setPreferredSize(new Dimension(50, 25));
            Theme.AppTheme(B4_edit, SystemSettings.getSettings().getCurrentTheme());
        }
        return B4_edit;
    }

    public void setB4_edit(JButton B4_edit) {
        this.B4_edit = B4_edit;
    }
    
    public void updateTheme(){
        Theme.AppTheme(B2_open_options, SystemSettings.getSettings().getCurrentTheme() ) ;
        Theme.AppTheme(B1_open_menu, SystemSettings.getSettings().getCurrentTheme() ) ;
        Theme.AppTheme(B3_backTo, SystemSettings.getSettings().getCurrentTheme());
        Theme.AppTheme(B4_edit, SystemSettings.getSettings().getCurrentTheme());
        Theme.AppTheme(this, SystemSettings.getSettings().getCurrentTheme() ) ;
    }
    
    
}
